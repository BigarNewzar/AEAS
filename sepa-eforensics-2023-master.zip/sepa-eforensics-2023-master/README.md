# Automated eForensics Analysis System
Graphical app that will automatically perform a forensic analysis against a disk image.
